import React from "react";
import { ImageBackground, StyleSheet, View, Image, Text } from "react-native";

const WelcomeScreen = () => {
  return (
    <ImageBackground
      style={{ width: "100%", height: "100%" }}
      source={require("../assets/background.jpg")}
    >
      <View style={{ paddingTop: 80, paddingLeft: 150 }}>
        <TouchableOpacity onPress={() => Alert.alert("logo clicked")}>
          <Image
            style={styles.logo}
            source={require("../assets/logo-red.png")}
          ></Image>
        </TouchableOpacity>
      </View>

      <Text style={styles.text}>Sell What You Don't Need</Text>

      <View style={[styles.container1]}></View>
      <View style={styles.container2}></View>
    </ImageBackground>
  );
};
export default WelcomeScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  logo: {
    paddingTop: 70,
    height: 120,
    width: 120,
    justifyContent: "center",
    alignItems: "center",
  },
  text: {
    paddingTop: 10,
    paddingLeft: 120,
    justifyContent: "center",
    alignItems: "center",
  },
  container1: {
    flex: 0.85,
    backgroundColor: "#fc5c65",

    marginTop: 500,
    justifyContent: "flex-end",
  },
  container2: {
    flex: 0.85,
    backgroundColor: "#4ECDC4",
    justifyContent: "flex-end",
  },
});
